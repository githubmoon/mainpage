package bean;

import java.util.Date;
import java.util.Map;

import javax.print.DocFlavor.STRING;

public class Reminddata {
	
	private String reminder;
	private String remper;
	private String remthing;
	private String remfreq;
	private String remway;


	public String getReminder() {
		return reminder;
	}
	public String getRemper() {
		return remper;
	}


	
}
