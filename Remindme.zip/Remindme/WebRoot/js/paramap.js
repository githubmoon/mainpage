
var tranReminder = {
	"yangr":"杨睿",
	"gaoy":"高勇",
	"zhanglch":"张立超",
	"zengj":"曾菁",
	"xiongshj":"熊圣杰",
	"liaotl":"廖腾龙",
	"lik":"李科",
	"yangj":"杨进",
	"longch":"龙超",
    "liw":"李文",
    "zhujg":"朱加贵",
	"linchb":"林长波",
	"liqs":"李清松",
	"chenyq":"陈云强",
	"zhangq":"张强"
	
};

var tranRemindper = {
	"yangr":"杨睿",
	"gaoy":"高勇",
	"zhanglch":"张立超",
	"zengj":"曾菁",
	"xiongshj":"熊圣杰",
	"liaotl":"廖腾龙",
	"lik":"李科",
	"yangj":"杨进",
	"longch":"龙超",
    "liw":"李文",
    "zhujg":"朱加贵",
	"linchb":"林长波",
	"liqs":"李清松",
	"chenyq":"陈云强",
	"zhangq":"张强"
};

var tranRemindfreq = {
		"O":"仅此一次",
		"D":"每天一次",
		"W":"每周一次",
		"M":"每月一次"		
};

var tranRemindway = {
		"MSG" : "短信",
		"MAIL" :"邮件",
		"WX":"微信"
};

var tranValflag = {
		"Y":"有效",
		"N":"失效"	
};

